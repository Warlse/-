/* global $:true */

+ function($) {
  "use strict";


}($);
