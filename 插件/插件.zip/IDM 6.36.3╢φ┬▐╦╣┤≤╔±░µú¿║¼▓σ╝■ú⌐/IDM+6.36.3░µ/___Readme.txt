﻿
	Друзья. 
 Работа над проектом LRepacks.ru ведётся ИСКЛЮЧИТЕЛЬНО благодаря материальной поддержке его пользователей.
 Без Вашей помощи создание репаков будет невозможным!

 Если для вас этот репак оказался полезен, внесите свой вклад в дальнейшую работу и развитие LRepacks.ru любым доступным и удобным 
 способом на странице https://lrepacks.ru/donate.html Полезной окажется ЛЮБАЯ, даже совсем незначительная на ваш взгляд, сумма.

 Поддержав проект, вы становитесь его Меценатом и получаете Premium доступ на сайте.
 Подробнее по сылке https://lrepacks.ru/informaciya/206-podderzhka-proekta-i-poluchenie-premium-dostupa.html

 Помните, что даже просто загружая репаки со страниц LRepacks.ru вы, пусть и немного, но тоже оказываете посильную помощь.
 В то время как загрузка репаков со сторонних ресурсов, не только подрывает его работу, но и является небезопасной для вас.


     							           		    			    Спасибо за понимание.


 ***********************************************************************************************************************************


	Friends.
 Work on the project LRepacks.ru is conducted exclusively due to financial support from its users.
 Without your help creating repacks will be impossible!

 If this repack proved to be useful for you, make a contribution to further work and development LRepacks.ru any available 
 and convenient  way to https://lrepacks.ru/donate.html Any amount would be useful, even very small in your opinion.

 After your support of the project, you become its Patron and get Premium Access on site.
 More details on the link https://lrepacks.ru/informaciya/206-podderzhka-proekta-i-poluchenie-premium-dostupa.html

 Remember that even just downloading repacks from the pages LRepacks.ru you, even a little, but also render possible assistance.
 Loading repacks from the third-party resources undermines the site work and also it might not be safe for you. 


     							           		    			Thank you for understanding.

